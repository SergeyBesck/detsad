<!DOCTYPE html>
<html lang="en">
<head>
    <?php include './temp/header.php'; ?>
</head>
<body>
    <header>
    <?php include './temp/nav.php'; ?>
</header>

<main>
<div class="container">
    <div class="row">
        <div class="col-4">
<p>Муниципальное бюджетное дошкольное образовательное учреждение 
    муниципального образования город Краснодар "Детский сад для детей раннего возраста "Солнце моё"</p>
</div>
<div class="col-7">
    <img src="../img/index.png" alt="" style="width-40px">
</div>
</div>
    </div>
</main>
<footer>
<?php include './temp/footer.php';?>
</footer>
</body>
</html>