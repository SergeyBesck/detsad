<?php 
include './temp/database.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include './temp/header.php';?>
    
</head>
<body>
    <header>
    <?php include './temp/nav.php';?>
    </header> 
    <main>
        <div class="container mb-5">
            <div class="row">
                <div class="col-1"></div>
                <div class="col-10">
                    <?php if(isset($_SESSION['error_message'])){ ?>
                        <div class="alert alert-danger" role="alert">
                       <?= $_SESSION['error_message'] ?>
                        </div>
                        <?php  } ?>
                    <form action="./script/login.php" method="post">
                   Логин:<input type="text" name="login">
                   Пароль:<input type="password" name="password">
                   <input type="submit" value="Войти">
                </form>
                </div>
                <div class="col-1"></div>
            </div>
        </div>
    </main>
    <footer>
       <?php include './temp/footer.php';?>
    </footer>
</body>
</html>
<?php
unset($_SESSION['error_message']);
?>