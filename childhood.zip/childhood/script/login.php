<?php include '../temp/database.php';
session_start();
if(empty($_POST['login']) || empty($_POST['password'])){
    $_SESSION['error_message'] = "Введены неполные данные!";
    header('location: ../login.php');
    exit;
}   
$login = $_POST['login'];
$password = $_POST['password'];
$sql= "SELECT * FROM users, role WHERE login='$login' AND password='$password', id_role.role = id_role.user limit 1;";
$result = $mysqli->query($sql);

if($result->num_rows > 0){ 
    $user = $result->fetch_assoc();
    $_SESSION['login'] = $user['login'];
    $_SESSION['id_user'] = $user['id_user'];
    $_SESSION['role'] = $user['role'];
    if($user['role'] == 2){
        header('location: ../cabinet.php');
    }
    else {
        header('location: ../order.php');
    }
}   else{
    $_SESSION['error_message'] = "Проверьте данные!";
    header('location: ../login.php');
}
?>