<?php 
session_start();
if(empty($_SESSION['id_user'])){
    header('location: ../login.php');
    exit;
}
include '../temp/database.php';

$id_order = $_GET['id_order'];
$sql = "UPDATE orders  SET status = '3' WHERE id_order='$id_order'";
$mysqli->query($sql);

header('location: ../cabinet.php');