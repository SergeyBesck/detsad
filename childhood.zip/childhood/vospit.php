<!DOCTYPE html>
<html lang="en">
<head>
    <?php include './temp/header.php'; ?>
</head>
<body>
    <header>
    <?php include './temp/nav.php'; ?>
</header>

<main>
<div class="container">
    <div class="row">

</div>
    </div>
</main>
<footer>
<?php include './temp/footer.php';?>
</footer>
</body>
</html>