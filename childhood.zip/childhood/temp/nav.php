<div class="container-xxl" style="background-color: green; height: 100px" >
            <div class="row">
                <div >                
                    <nav class="navbar navbar-expand-lg navbar-dark  text-white ">
                    <div class="container-fluid">
                    <div class="col-1">
                        <img src="../img/title.png" alt="" style="height:70px">
                    </div>
                    <div class="col-9">
                    <h1>Детский Сад "Солнце моё</h1>
                    </div>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav" style="margin-top: 40px">
                            <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="./index.php">Главная</a>
                            <?php if (!isset($_SESSION['login']) ) {?>
                            </li>
                            <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="./login.php">Вход</a>
                            </li>
                            <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="./logout.php">Выйти</a>
                            </li>
                            <?php } ?>

                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 1 ) {?>
                            <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="./vospit.php">Табель учёта</a>
                            </li>

                            <?php }?>
                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 2 ) {?>
                            <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="./med.php">Учёт заболеваемости</a>
                            </li>
                            <?php }?>
                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 3 ) {?>
                            <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="./admin.php">Отчеты</a>
                            </li>
                            <?php }?>
                        </ul>
                        </div>
                     </div>
                    </nav>
                </div>
            </div>
        </div>