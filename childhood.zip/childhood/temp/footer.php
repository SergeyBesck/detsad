<div class="container-xxl  text-white" style="background-color: green; ">
         <div class="row">
             <div class="col-1"></div>
             <div class="col-4">                    
                <div class ="copy">
                <p class = "p1">
                Copyright <?php echo '&copy2022'; ?>
                </p>
            </div></div>  
             <div class="col-4">
                <div class="text">
                    <p>Контакты:</p>
                    <p>г. Краснодар, ул.Домбайская 12, кв-26</p>
                    <a class="phone" href="#"><i class="fa fa-phone"></i>+7-960-485-53-04</a>&nbsp;&nbsp;
                    <a class="envelope" href="#"><i class="fa fa-envelope"></i>andry.k2005@mail.ru</a>
                </div>
             </div>
             <div class="col-2"></div>    
             <div class="col-1"></div>
         </div>
     </div>